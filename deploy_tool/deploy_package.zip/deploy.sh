#!/bin/bash
echo "🚀 Starting Deployment..."
php deploy_tool/cli_deploy.php
echo "✅ Done!"
